package com.bw.osgi.provider.able;

public interface HelloWorldService {
    void hello();
}